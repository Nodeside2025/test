window.LF = (window.LF || []).concat([
{
  id: 5, jahr: 2, std: 80,
  titel: "Zwischenfällen vorbeugen und in Notfallsituationen Hilfe leisten",
  bereiche: ["Behandlungsassistenz", "Praxisorganisation"],
  intro: "In einer Arztpraxis kann jederzeit ein Notfall eintreten. Du lernst Herz und Kreislauf, das EKG, das Erkennen lebensbedrohlicher Zustände, die Reanimation und das Notfallmanagement in der Praxis.",
  ziele: [
    "Den Blutkreislauf und die Erregungsleitung des Herzens beschreiben",
    "Ein Ruhe-EKG korrekt anlegen",
    "Bewusstsein, Atmung und Kreislauf prüfen und einen Notruf absetzen",
    "Eine Herz-Lungen-Wiederbelebung mit AED durchführen",
    "Herzinfarkt, Schlaganfall, Hypoglykämie, Anaphylaxie und Asthmaanfall erkennen"
  ],
  kapitel: [
    { t: "Herz und Kreislauf",
      h: "<p>Das Herz hat zwei Vorhöfe und zwei Kammern. Der Weg des Blutes:</p><p class='weg'>Körpervenen → rechter Vorhof → Trikuspidalklappe → rechte Kammer → Pulmonalklappe → Lungenarterie → Lunge (Sauerstoffaufnahme) → Lungenvenen → linker Vorhof → Mitralklappe → linke Kammer → Aortenklappe → Aorta → Körper</p><p><strong>Arterien</strong> führen Blut vom Herzen weg, <strong>Venen</strong> zum Herzen hin. Die Lungenarterie führt also sauerstoffarmes Blut.</p><p><strong>Erregungsleitung:</strong> Sinusknoten (Taktgeber, ca. 60–80/min) → AV-Knoten → His-Bündel → Tawara-Schenkel → Purkinje-Fasern.</p><p><strong>Herzzyklus:</strong> Systole (Anspannung und Auswurf) und Diastole (Entspannung und Füllung).</p>",
      merke: "Arterie = vom Herzen weg, egal ob das Blut sauerstoffreich ist." },
    { t: "Das Ruhe-EKG",
      h: "<p><strong>EKG-Kurve:</strong> P-Welle = Erregung der Vorhöfe, QRS-Komplex = Erregung der Kammern, T-Welle = Erregungsrückbildung der Kammern.</p><p><strong>Standardableitungen (12-Kanal):</strong></p><ul><li>Extremitätenableitungen nach Einthoven (I, II, III) und Goldberger (aVR, aVL, aVF)</li><li>Brustwandableitungen nach Wilson (V1–V6)</li></ul><p><strong>Extremitätenelektroden („Ampel“ im Uhrzeigersinn ab rechtem Arm):</strong></p><table><tbody><tr><td>rechter Arm</td><td>rot</td></tr><tr><td>linker Arm</td><td>gelb</td></tr><tr><td>linkes Bein</td><td>grün</td></tr><tr><td>rechtes Bein</td><td>schwarz (Erde)</td></tr></tbody></table><p><strong>Brustwand:</strong> V1 im 4. Zwischenrippenraum rechts am Brustbein, V2 im 4. ICR links am Brustbein, V4 im 5. ICR in der Medioklavikularlinie links, V3 zwischen V2 und V4, V5 und V6 auf Höhe von V4 in der vorderen bzw. mittleren Axillarlinie.</p><p><strong>Fehler vermeiden:</strong> Patient liegt entspannt, nicht frieren, nicht sprechen; Haut ggf. entfetten; Elektroden nicht vertauschen; Handy und Kabelsalat fern halten.</p>",
      merke: "Rot, Gelb, Grün im Uhrzeigersinn, Schwarz rechts unten." },
    { t: "Notfall erkennen und Notruf",
      h: "<p><strong>Erst prüfen:</strong> Ist die Umgebung sicher? Dann ansprechen und anfassen (Bewusstsein), Atemwege freimachen (Kopf überstrecken, Kinn anheben), Atmung prüfen: <strong>sehen, hören, fühlen, höchstens 10 Sekunden</strong>.</p><ul><li><strong>Bewusstlos, normale Atmung:</strong> stabile Seitenlage, Notruf, Atmung weiter kontrollieren.</li><li><strong>Bewusstlos, keine normale Atmung</strong> (auch Schnappatmung): Notruf 112, AED holen lassen, sofort Herzdruckmassage.</li></ul><p><strong>Notruf 112 – W-Fragen:</strong> Wo ist der Notfall? Was ist passiert? Wie viele Betroffene? Welche Verletzungen oder Symptome? Warten auf Rückfragen.</p><p><strong>Schock:</strong> blasse, kalte, feuchte Haut, schneller, schwacher Puls, niedriger Blutdruck, Unruhe. Schockindex = Puls ÷ systolischer Blutdruck; über 1 deutet auf einen Schock hin. Schocklagerung (Beine hoch), außer bei Herzversagen, Atemnot oder Verletzungen von Kopf, Brustkorb oder Bauch.</p>",
      merke: "Schnappatmung ist keine normale Atmung. Dann sofort mit der Herzdruckmassage beginnen." },
    { t: "Wiederbelebung (Erwachsene)",
      h: "<ol><li>Notruf veranlassen, AED holen lassen.</li><li>Patient auf harter Unterlage, Oberkörper frei.</li><li><strong>Herzdruckmassage:</strong> Druckpunkt Mitte des Brustkorbs (untere Hälfte des Brustbeins), Arme gestreckt, <strong>5–6 cm</strong> tief, <strong>100–120 pro Minute</strong>, vollständig entlasten.</li><li><strong>30 Kompressionen : 2 Beatmungen</strong> (bei Laien auch nur Herzdruckmassage).</li><li><strong>AED</strong> sobald verfügbar einschalten und den Sprachanweisungen folgen; während der Analyse und Schockabgabe niemand berührt den Patienten.</li><li>Weitermachen, bis der Rettungsdienst übernimmt oder der Patient normal atmet. Helfer alle 2 Minuten wechseln.</li></ol><p>Unterbrechungen der Herzdruckmassage so kurz wie möglich halten.</p>",
      merke: "30:2, 100–120 pro Minute, 5–6 cm tief. Drücken ist wichtiger als Beatmen." },
    { t: "Typische Notfälle in der Praxis",
      h: "<table><thead><tr><th>Notfall</th><th>Erkennen</th><th>Erstmaßnahmen der MFA</th></tr></thead><tbody><tr><td>Herzinfarkt</td><td>Brustschmerz über 20 Min., Ausstrahlung in Arm, Hals, Kiefer, Oberbauch; Atemnot, Kaltschweißigkeit; bei Frauen und Diabetikern oft untypisch</td><td>Arzt rufen, Notruf, Oberkörper hoch lagern, beengende Kleidung öffnen, beruhigen, keine i.m.-Injektion, Notfallkoffer und EKG bereit</td></tr><tr><td>Schlaganfall</td><td>FAST: Face (hängender Mundwinkel), Arms (Arm sinkt ab), Speech (verwaschene Sprache), Time (Zeit notieren)</td><td>Notruf, Beginn der Symptome notieren, Oberkörper leicht hoch, nichts zu essen oder trinken</td></tr><tr><td>Unterzuckerung</td><td>Zittern, Schwitzen, Heißhunger, Unruhe, Verwirrtheit bis Bewusstlosigkeit</td><td>Blutzucker messen; bei Bewusstsein Traubenzucker oder zuckerhaltiges Getränk; bewusstlos: nichts in den Mund, Arzt, Notruf</td></tr><tr><td>Anaphylaxie</td><td>Juckreiz, Quaddeln, Schwellung, Atemnot, Blutdruckabfall, z. B. nach Injektion oder Insektenstich</td><td>Arzt sofort holen, Zufuhr stoppen, Notfallmedikamente bereitstellen (Adrenalin), Lagerung nach Zustand, Notruf</td></tr><tr><td>Asthmaanfall</td><td>Atemnot, pfeifende Ausatmung, verlängertes Ausatmen</td><td>Oberkörper hoch, Kutschersitz, Lippenbremse, Notfallspray des Patienten, Arzt</td></tr></tbody></table><p><strong>Vorbeugen:</strong> Notfallplan und Rollenverteilung, Notfallkoffer und Sauerstoff regelmäßig auf Vollständigkeit und Verfallsdaten prüfen (Checkliste), regelmäßiges Notfalltraining des Teams, Patienten nach Injektionen beobachten.</p>",
      merke: "Bei Verdacht auf Herzinfarkt keine Injektion in den Muskel." }
  ],
  karten: [
    ["Welche Klappe liegt zwischen linkem Vorhof und linker Kammer?", "Die Mitralklappe."],
    ["Was zeigt der QRS-Komplex?", "Die Erregung (Depolarisation) der Herzkammern."],
    ["Elektrodenfarbe am linken Bein?", "Grün."],
    ["Wo liegt V1?", "Im 4. Zwischenrippenraum rechts neben dem Brustbein."],
    ["Frequenz und Tiefe der Herzdruckmassage bei Erwachsenen?", "100–120/min, 5–6 cm."],
    ["Wofür steht FAST?", "Face, Arms, Speech, Time – Schnelltest bei Verdacht auf Schlaganfall."],
    ["Was ist der Schockindex?", "Puls geteilt durch systolischen Blutdruck. Über 1 spricht für einen Schock."],
    ["Lagerung bei Asthmaanfall?", "Oberkörper hoch, Kutschersitz mit aufgestützten Armen, Lippenbremse."]
  ],
  mc: [
    { q: "In welche Herzhöhle fließt das sauerstoffreiche Blut aus der Lunge zuerst?", o: ["Rechter Vorhof", "Rechte Kammer", "Linker Vorhof", "Linke Kammer"], a: 2, e: "Über die Lungenvenen gelangt das sauerstoffreiche Blut in den linken Vorhof." },
    { q: "Welche Struktur ist der natürliche Taktgeber des Herzens?", o: ["AV-Knoten", "Sinusknoten", "His-Bündel", "Purkinje-Fasern"], a: 1, e: "Der Sinusknoten im rechten Vorhof gibt den Grundrhythmus vor." },
    { q: "Welche Elektrode gehört an den linken Arm?", o: ["rot", "gelb", "grün", "schwarz"], a: 1, e: "Rot rechter Arm, gelb linker Arm, grün linkes Bein, schwarz rechtes Bein." },
    { q: "Was zeigt die P-Welle im EKG?", o: ["Kammererregung", "Vorhoferregung", "Erregungsrückbildung der Kammern", "Erregungsleitung im AV-Knoten"], a: 1, e: "Die P-Welle entspricht der Erregung der Vorhöfe." },
    { q: "Ein Patient bricht im Wartezimmer zusammen, reagiert nicht und atmet nicht normal. Was ist nach dem Notruf zu tun?", o: ["Stabile Seitenlage", "Beine hochlagern und abwarten", "Sofort Herzdruckmassage beginnen", "Blutdruck messen"], a: 2, e: "Ohne normale Atmung wird sofort mit der Herzdruckmassage begonnen und ein AED eingesetzt." },
    { q: "Welches Verhältnis von Kompressionen zu Beatmungen gilt bei Erwachsenen?", o: ["15:2", "30:2", "5:1", "30:5"], a: 1, e: "Bei Erwachsenen 30 Kompressionen zu 2 Beatmungen." },
    { q: "Welches Symptom passt NICHT zum typischen Herzinfarkt?", o: ["Brustschmerz über 20 Minuten", "Ausstrahlung in den linken Arm", "Kaltschweißigkeit", "Schmerz, der sich beim Drücken auf eine Rippe genau auslösen lässt"], a: 3, e: "Ein exakt auslösbarer Druckschmerz spricht eher für eine Ursache an Muskeln oder Rippen." },
    { q: "Eine Patientin mit Diabetes ist plötzlich zittrig, schwitzt und wirkt verwirrt, ist aber ansprechbar. Was tust du zuerst (nach Rücksprache bzw. Info an den Arzt)?", o: ["Insulin spritzen", "Blutzucker messen und Traubenzucker geben", "Sie nach Hause schicken", "Flach hinlegen und nichts geben"], a: 1, e: "Die Zeichen sprechen für eine Unterzuckerung. Bei erhaltenem Bewusstsein schnell wirksamen Zucker geben." },
    { q: "Wofür steht das „T“ im FAST-Test?", o: ["Temperatur", "Time – Zeitpunkt notieren und sofort Notruf", "Tablette geben", "Tastbefund"], a: 1, e: "Beim Schlaganfall zählt jede Minute. Der Zeitpunkt des Symptombeginns ist für die Therapie entscheidend." },
    { q: "Bei welchem Zustand ist die Schocklagerung (Beine hoch) ungeeignet?", o: ["Volumenmangel nach Blutverlust", "Kreislaufkollaps", "Herzinfarkt mit Atemnot", "Ohnmacht nach Blutentnahme"], a: 2, e: "Bei Herzversagen und Atemnot würde die Schocklagerung das Herz zusätzlich belasten. Hier wird der Oberkörper hoch gelagert." }
  ],
  fall: [
    { q: "Herr Schulz (63) klagt im Wartezimmer über starke Schmerzen hinter dem Brustbein, die in den linken Arm ziehen. Er ist blass und schwitzt. Beschreibe deine Maßnahmen bis zum Eintreffen des Rettungsdienstes in sinnvoller Reihenfolge.", p: 20, l: "<ol><li>Arzt sofort informieren, Kolleginnen alarmieren (Notfallplan) – 3 P.</li><li>Notruf 112 mit W-Fragen (oft durch zweite Person) – 3 P.</li><li>Patient nicht laufen lassen, Oberkörper hoch lagern, beengende Kleidung öffnen, beruhigen – 4 P.</li><li>Vitalzeichen messen (Puls, Blutdruck), EKG und Notfallkoffer, Sauerstoff und AED bereitstellen – 4 P.</li><li>Keine i.m.-Injektion; Zeitpunkt des Schmerzbeginns und Medikamente notieren – 3 P.</li><li>Ständige Überwachung, bei Bewusstlosigkeit ohne normale Atmung sofort Reanimation – 3 P.</li></ol>" },
    { q: "Du sollst bei einer Patientin ein 12-Kanal-Ruhe-EKG schreiben. Beschreibe Vorbereitung, das Anlegen der Elektroden und drei typische Fehlerquellen.", p: 20, l: "<p><strong>Vorbereitung (5 P.):</strong> Patientin informieren, Oberkörper und Unterschenkel bzw. Knöchel frei, entspannte Rückenlage, warmer Raum, Haut ggf. entfetten, Daten am Gerät eingeben.</p><p><strong>Anlegen (9 P.):</strong> Extremitäten: rot rechter Arm, gelb linker Arm, grün linkes Bein, schwarz rechtes Bein. Brustwand: V1 4. ICR rechts parasternal, V2 4. ICR links parasternal, V4 5. ICR Medioklavikularlinie, V3 dazwischen, V5 vordere, V6 mittlere Axillarlinie auf Höhe V4.</p><p><strong>Fehler (je 2 P.):</strong> Muskelzittern durch Kälte oder Anspannung, vertauschte Elektroden, schlechter Hautkontakt, Wechselstromstörungen, Sprechen oder Bewegung.</p>" }
  ]
},
{
  id: 6, jahr: 2, std: 80,
  titel: "Waren beschaffen und verwalten",
  bereiche: ["Praxisorganisation", "WiSo"],
  intro: "Ohne Material keine Behandlung. Du lernst, wie man Bedarf ermittelt, Angebote vergleicht, Kaufverträge abschließt, mit Lieferproblemen umgeht und Waren sachgerecht lagert. Dazu gehören Sprechstundenbedarf und Zahlungsverkehr.",
  ziele: [
    "Melde-, Mindest- und Höchstbestand berechnen",
    "Angebote quantitativ und qualitativ vergleichen",
    "Zustandekommen und Pflichten aus dem Kaufvertrag erklären",
    "Bei mangelhafter Lieferung und Lieferverzug richtig handeln",
    "Praxisbedarf, Sprechstundenbedarf und Einzelverordnung unterscheiden"
  ],
  kapitel: [
    { t: "Bedarf und Lagerhaltung",
      h: "<ul><li><strong>Mindestbestand (eiserne Reserve):</strong> Vorrat für Störfälle, wird normalerweise nicht angetastet.</li><li><strong>Meldebestand:</strong> Bei Erreichen wird bestellt.<br><span class='formel'>Meldebestand = Tagesverbrauch × Lieferzeit + Mindestbestand</span></li><li><strong>Höchstbestand:</strong> maximal sinnvolle Lagermenge (Platz, Kapital, Verfall).</li></ul><p><strong>Lagergrundsätze:</strong> Sauberkeit, Übersichtlichkeit, Ware mit dem kürzesten Verfallsdatum zuerst verbrauchen (<strong>First expired, first out</strong>), regelmäßige Verfallskontrolle.</p><p><strong>Besondere Lagerung:</strong></p><ul><li>Impfstoffe und viele Medikamente im Medikamentenkühlschrank bei <strong>+2 bis +8 °C</strong>, Temperatur täglich dokumentieren, nicht in der Kühlschranktür lagern.</li><li><strong>Betäubungsmittel</strong> in einem gesonderten, gegen Diebstahl gesicherten Schrank; Zu- und Abgänge lückenlos dokumentieren (BtM-Karteikarten bzw. -Buch).</li></ul>",
      merke: "Kühlkette bei Impfstoffen nie unterbrechen. Gefrorener Impfstoff ist unbrauchbar." },
    { t: "Angebotsvergleich",
      h: "<p>Beim <strong>quantitativen Vergleich</strong> wird der Bezugspreis berechnet:</p><table class='kalk'><tbody><tr><td></td><td>Listeneinkaufspreis</td></tr><tr><td>−</td><td>Rabatt</td></tr><tr><td>=</td><td>Zieleinkaufspreis</td></tr><tr><td>−</td><td>Skonto</td></tr><tr><td>=</td><td>Bareinkaufspreis</td></tr><tr><td>+</td><td>Bezugskosten (Fracht, Verpackung)</td></tr><tr><td>=</td><td>Bezugspreis (Einstandspreis)</td></tr></tbody></table><p><strong>Beispiel:</strong> 200 € Listenpreis, 10 % Rabatt → 180 €; 2 % Skonto → 176,40 €; 5 € Versand → <strong>181,40 €</strong>.</p><p><strong>Qualitativer Vergleich:</strong> Qualität, Lieferzeit, Zuverlässigkeit, Service, Umweltverträglichkeit, Erreichbarkeit.</p>",
      merke: "Erst Rabatt, dann Skonto, dann Bezugskosten." },
    { t: "Der Kaufvertrag",
      h: "<p>Ein Kaufvertrag kommt durch <strong>zwei übereinstimmende Willenserklärungen</strong> zustande: Antrag und Annahme.</p><ul><li>Angebot des Lieferanten (Antrag) + Bestellung (Annahme), oder</li><li>Bestellung ohne vorheriges Angebot (Antrag) + Auftragsbestätigung oder Lieferung (Annahme).</li></ul><p>Ein Angebot ist grundsätzlich <strong>verbindlich</strong>, außer es enthält Freizeichnungsklauseln wie „freibleibend“ oder „solange der Vorrat reicht“. Werbung im Katalog ist kein Angebot, sondern eine Aufforderung zur Bestellung.</p><p><strong>Pflichten</strong></p><ul><li>Verkäufer: Ware rechtzeitig und mangelfrei übergeben, Eigentum verschaffen, Kaufpreis annehmen</li><li>Käufer: Ware annehmen, Kaufpreis rechtzeitig zahlen</li></ul>",
      merke: "Angebot + Bestellung = Vertrag. Bestellung ohne Angebot braucht eine Bestätigung oder die Lieferung." },
    { t: "Störungen beim Kaufvertrag",
      h: "<p><strong>Mangelhafte Lieferung:</strong> falsche Menge, falsche Ware, beschädigte Ware, fehlende Eigenschaft. Ware sofort prüfen und Mängel unverzüglich melden (Mängelrüge). Gewährleistungsfrist in der Regel <strong>2 Jahre</strong>.</p><p>Rechte des Käufers:</p><ol><li><strong>Vorrangig: Nacherfüllung</strong> (Nachbesserung oder Ersatzlieferung)</li><li>Wenn diese scheitert: Rücktritt vom Vertrag oder Minderung des Preises</li><li>Zusätzlich bei Verschulden: Schadensersatz</li></ol><p><strong>Lieferungsverzug:</strong> Die Lieferung ist fällig, aber nicht erfolgt. In der Regel ist eine Mahnung nötig; sie entfällt, wenn ein Termin kalendermäßig festgelegt ist (z. B. „Lieferung am 15.03.“). Dann kann der Käufer eine angemessene Nachfrist setzen und danach zurücktreten bzw. bei Verschulden Schadensersatz verlangen.</p><p><strong>Zahlungsverzug:</strong> Der Käufer zahlt nicht rechtzeitig, der Verkäufer kann Verzugszinsen verlangen.</p>",
      merke: "Erst Nacherfüllung verlangen. Rücktritt und Minderung kommen danach." },
    { t: "Sprechstundenbedarf und Zahlungsverkehr",
      h: "<table><thead><tr><th>Art</th><th>Beispiele</th><th>Wer zahlt?</th></tr></thead><tbody><tr><td>Praxisbedarf</td><td>Flächendesinfektion, Büromaterial, Untersuchungshandschuhe, Geräte</td><td>Die Praxis selbst</td></tr><tr><td>Sprechstundenbedarf (SSB)</td><td>Mittel, die für mehrere GKV-Patienten in der Praxis angewendet werden, z. B. Notfallmedikamente, Lokalanästhetika, kleine Mengen Verbandmaterial</td><td>Krankenkassen nach der regionalen SSB-Vereinbarung (in S-H mit der KVSH), Bestellung auf Muster 16 mit Kennzeichnung „Spr.-St. Bedarf“</td></tr><tr><td>Einzelverordnung</td><td>Medikament für einen bestimmten Patienten</td><td>Krankenkasse des Patienten (Rezept auf dessen Namen)</td></tr></tbody></table><p>Was als SSB bezogen werden darf, regelt die regionale Vereinbarung. Fehler können zu Regressen führen.</p><p><strong>Zahlungsverkehr:</strong> Überweisung (SEPA mit IBAN), Lastschrift, Kartenzahlung. Rechnungen vor Zahlung auf Richtigkeit prüfen (Menge, Preis, Rabatt, Skonto-Frist nutzen).</p>",
      merke: "Was nur für die Praxis ist, zahlt die Praxis. Was für mehrere Kassenpatienten angewendet wird, kann SSB sein." }
  ],
  karten: [
    ["Formel Meldebestand?", "Tagesverbrauch × Lieferzeit + Mindestbestand."],
    ["Welche Temperatur gilt für Impfstoff-Kühlschränke?", "+2 bis +8 °C."],
    ["Reihenfolge der Bezugspreiskalkulation?", "Listenpreis − Rabatt = Zieleinkaufspreis − Skonto = Bareinkaufspreis + Bezugskosten = Bezugspreis."],
    ["Was macht ein Angebot unverbindlich?", "Freizeichnungsklauseln wie „freibleibend“ oder „solange Vorrat reicht“."],
    ["Welches Recht hat der Käufer bei Mängeln zuerst?", "Nacherfüllung (Nachbesserung oder Ersatzlieferung)."],
    ["Wann ist beim Lieferungsverzug keine Mahnung nötig?", "Wenn der Liefertermin kalendermäßig bestimmt ist."],
    ["Unterschied Praxisbedarf und Sprechstundenbedarf?", "Praxisbedarf zahlt die Praxis selbst; SSB wird für mehrere GKV-Patienten verwendet und über die Kassen bezogen."],
    ["Wie werden Betäubungsmittel gelagert?", "Gesondert in einem gesicherten Schrank, Bestand lückenlos dokumentiert."]
  ],
  mc: [
    { q: "Der Tagesverbrauch an Tupfern beträgt 20 Packungen, die Lieferzeit 3 Tage, der Mindestbestand 40 Packungen. Wie hoch ist der Meldebestand?", o: ["60", "80", "100", "120"], a: 2, e: "20 × 3 + 40 = 100 Packungen." },
    { q: "Was bedeutet „First expired, first out“?", o: ["Das zuletzt gelieferte zuerst verbrauchen", "Das Produkt mit dem frühesten Verfallsdatum zuerst verbrauchen", "Das teuerste Produkt zuerst verbrauchen", "Abgelaufene Ware zuerst verbrauchen"], a: 1, e: "So wird verhindert, dass Ware im Lager verfällt." },
    { q: "Listenpreis 500 €, 10 % Rabatt, 2 % Skonto, 10 € Bezugskosten. Wie hoch ist der Bezugspreis?", o: ["441,00 €", "451,00 €", "460,00 €", "449,00 €"], a: 1, e: "500 − 50 = 450; 450 − 9 = 441; 441 + 10 = 451 €." },
    { q: "Ein Lieferant schickt ein Angebot mit dem Zusatz „freibleibend“. Was bedeutet das?", o: ["Das Angebot ist verbindlich", "Das Angebot ist unverbindlich", "Die Lieferung ist kostenlos", "Die Ware ist versandkostenfrei"], a: 1, e: "„Freibleibend“ ist eine Freizeichnungsklausel. Der Anbieter ist nicht an das Angebot gebunden." },
    { q: "Die Praxis bestellt ohne vorheriges Angebot. Wann ist der Kaufvertrag zustande gekommen?", o: ["Mit dem Absenden der Bestellung", "Mit der Auftragsbestätigung oder der Lieferung", "Erst mit der Zahlung", "Mit dem Eingang der Rechnung"], a: 1, e: "Die Bestellung ist hier der Antrag. Erst die Annahme durch den Lieferanten (Bestätigung oder Lieferung) schließt den Vertrag." },
    { q: "Ein geliefertes Blutdruckgerät ist defekt. Was kann die Praxis zuerst verlangen?", o: ["Sofort Rücktritt", "Minderung", "Nacherfüllung", "Schadensersatz ohne Fristsetzung"], a: 2, e: "Vorrangig hat der Käufer Anspruch auf Nacherfüllung. Erst wenn sie scheitert, kommen Rücktritt oder Minderung in Betracht." },
    { q: "Wann liegt ein Lieferungsverzug ohne Mahnung vor?", o: ["Bei „Lieferung so schnell wie möglich“", "Bei „Lieferung am 12. Mai“", "Bei „Lieferung in den nächsten Wochen“", "Nie, eine Mahnung ist immer nötig"], a: 1, e: "Ist der Termin kalendermäßig bestimmt, gerät der Lieferant mit Ablauf des Tages ohne Mahnung in Verzug." },
    { q: "In welchem Temperaturbereich werden Impfstoffe gelagert?", o: ["−18 bis −20 °C", "0 bis +2 °C", "+2 bis +8 °C", "+15 bis +25 °C"], a: 2, e: "Impfstoffe gehören in den Medikamentenkühlschrank bei +2 bis +8 °C. Einfrieren macht sie unbrauchbar." },
    { q: "Was gehört typischerweise zum Praxisbedarf und wird von der Praxis selbst bezahlt?", o: ["Notfallmedikament für die Praxis", "Flächendesinfektionsmittel", "Insulin für einen bestimmten Patienten", "Lokalanästhetikum für Wundversorgungen"], a: 1, e: "Flächendesinfektion dient dem Praxisbetrieb und ist Praxisbedarf." },
    { q: "Auf welchem Formular wird Sprechstundenbedarf in der Regel angefordert?", o: ["Muster 1", "Muster 6", "Muster 10", "Muster 16"], a: 3, e: "SSB wird auf dem Arzneiverordnungsblatt (Muster 16) mit entsprechender Kennzeichnung bestellt; die Details regelt die regionale Vereinbarung." }
  ],
  fall: [
    { q: "Für Einmalspritzen liegen zwei Angebote vor. A: 300 € Listenpreis, 5 % Rabatt, 3 % Skonto, frei Haus. B: 290 € Listenpreis, kein Rabatt, 2 % Skonto, 6 € Versand. Berechne beide Bezugspreise, entscheide dich und nenne zwei qualitative Gesichtspunkte.", p: 20, l: "<p><strong>A (6 P.):</strong> 300 − 15 = 285; 285 − 8,55 = 276,45; + 0 = <strong>276,45 €</strong>.</p><p><strong>B (6 P.):</strong> 290 − 0 = 290; 290 − 5,80 = 284,20; + 6 = <strong>290,20 €</strong>.</p><p><strong>Entscheidung (2 P.):</strong> Angebot A ist günstiger.</p><p><strong>Qualitativ (6 P.):</strong> Lieferzeit, Zuverlässigkeit, Qualität, Service, Mindestbestellmenge, Umweltaspekte.</p>" },
    { q: "Bestellte Verbandmittel kommen am vereinbarten Liefertag nicht an. Zwei Tage später wird ein Paket mit beschädigten Packungen geliefert. Erkläre, welche Störungen vorliegen und welche Rechte die Praxis jeweils hat.", p: 20, l: "<p><strong>Lieferungsverzug (10 P.):</strong> Termin war fest vereinbart, daher Verzug ohne Mahnung. Die Praxis kann auf Lieferung bestehen, nach Nachfrist zurücktreten und bei Verschulden Schadensersatz (z. B. Mehrkosten eines Deckungskaufs) verlangen.</p><p><strong>Mangelhafte Lieferung (10 P.):</strong> Ware sofort prüfen, Mangel dokumentieren und unverzüglich rügen. Zuerst Nacherfüllung (Ersatzlieferung) verlangen; scheitert sie, Rücktritt oder Minderung, bei Verschulden zusätzlich Schadensersatz.</p>" }
  ]
},
{
  id: 7, jahr: 2, std: 60,
  titel: "Praxisabläufe im Team organisieren",
  bereiche: ["Praxisorganisation", "Abrechnung"],
  intro: "Eine gut organisierte Praxis spart Zeit und Nerven. Du lernst Terminplanung, Teamarbeit, Zeitmanagement, Qualitätsmanagement und wichtige Abrechnungsbegriffe für die Quartalsabrechnung.",
  ziele: [
    "Bestellsysteme vergleichen und einen Tagesplan mit Puffern erstellen",
    "Teamphasen und Regeln für Feedback anwenden",
    "Aufgaben mit der Eisenhower-Matrix priorisieren",
    "Den PDCA-Zyklus im Qualitätsmanagement erklären",
    "Behandlungsfall, Arztfall und Krankheitsfall unterscheiden"
  ],
  kapitel: [
    { t: "Terminplanung",
      h: "<ul><li><strong>Bestellsystem:</strong> feste Termine, planbare Wartezeiten, Leerlauf bei Absagen möglich.</li><li><strong>Offene Sprechstunde:</strong> flexibel, aber lange und schwer planbare Wartezeiten.</li><li><strong>Kombination:</strong> feste Termine plus Zeitfenster für Akutfälle – in der Praxis am häufigsten.</li></ul><p><strong>Gute Planung:</strong> Pufferzeiten für Notfälle und Akutpatienten, unterschiedliche Dauer je Leistung (z. B. Check-up länger als Rezeptabholung), Recall-System für Kontrollen und Vorsorge, Online-Terminbuchung, Erinnerung per SMS.</p><p>Die <strong>Terminservicestellen der KV</strong> (Rufnummer 116117) vermitteln gesetzlich Versicherten Facharzttermine.</p>",
      merke: "Ohne Puffer bringt jeder Notfall den ganzen Tag durcheinander." },
    { t: "Teamarbeit und Kommunikation",
      h: "<p><strong>Phasen der Teamentwicklung (Tuckman):</strong></p><ol><li><strong>Forming:</strong> Kennenlernen, Unsicherheit</li><li><strong>Storming:</strong> Konflikte, Positionen werden ausgehandelt</li><li><strong>Norming:</strong> Regeln und Rollen entstehen</li><li><strong>Performing:</strong> leistungsfähige Zusammenarbeit</li><li><strong>Adjourning:</strong> Auflösung bzw. Abschied</li></ol><p><strong>Feedback-Regeln:</strong> konkret und beschreibend statt bewertend, zeitnah, unter vier Augen, Ich-Botschaften, Verbesserungsvorschlag nennen. Der Empfänger hört zu, fragt nach und rechtfertigt sich nicht sofort.</p><p><strong>Teambesprechung:</strong> regelmäßig, mit Tagesordnung, Protokoll und klaren Zuständigkeiten (Wer macht was bis wann?).</p>",
      merke: "Konflikte in der Storming-Phase sind normal und gehören zur Teamentwicklung." },
    { t: "Zeit- und Selbstmanagement",
      h: "<p><strong>Eisenhower-Matrix:</strong></p><table><thead><tr><th></th><th>dringend</th><th>nicht dringend</th></tr></thead><tbody><tr><th>wichtig</th><td>A: sofort selbst erledigen</td><td>B: terminieren</td></tr><tr><th>nicht wichtig</th><td>C: delegieren</td><td>D: weglassen</td></tr></tbody></table><p><strong>Telefonmanagement:</strong> Begrüßung mit Praxisname und eigenem Namen, Anliegen klären, Notizen strukturiert, Rückrufe zu festen Zeiten, bei Notfallverdacht sofort weiterleiten bzw. 112 empfehlen.</p><p><strong>Postbearbeitung:</strong> Eingang mit Datum stempeln, Befunde dem Arzt vorlegen, abzeichnen lassen, einscannen bzw. in die Akte, Fristen notieren.</p>",
      merke: "Wichtig und dringend zuerst. Unwichtiges nicht nebenbei mitschleppen." },
    { t: "Qualitätsmanagement",
      h: "<p>Vertragsärzte sind durch die <strong>QM-Richtlinie des G-BA</strong> verpflichtet, ein einrichtungsinternes Qualitätsmanagement einzuführen und weiterzuentwickeln.</p><p><strong>PDCA-Zyklus:</strong></p><ul><li><strong>Plan:</strong> Ziel und Maßnahme festlegen</li><li><strong>Do:</strong> umsetzen</li><li><strong>Check:</strong> Ergebnis prüfen</li><li><strong>Act:</strong> Standard festlegen oder nachbessern, dann von vorn</li></ul><p><strong>QM-Systeme:</strong> QEP (Qualität und Entwicklung in Praxen, von den KVen und der KBV entwickelt), DIN EN ISO 9001 und andere.</p><p><strong>Instrumente:</strong> Checklisten, Verfahrens- und Arbeitsanweisungen, Patientenbefragung, Beschwerdemanagement, Fehlermanagement (z. B. Fehlerberichtssysteme wie CIRS), Notfallmanagement, Hygienemanagement.</p>",
      merke: "QM ist Pflicht. Der PDCA-Kreis hört nie auf." },
    { t: "Abrechnungsbegriffe im Quartal",
      h: "<ul><li><strong>Behandlungsfall:</strong> alle Behandlungen eines Patienten in derselben Praxis, im selben Quartal, zulasten derselben Krankenkasse.</li><li><strong>Arztfall:</strong> alle Leistungen bei einem Patienten durch denselben Arzt im Quartal (unabhängig vom Ort, z. B. in einer BAG mit mehreren Standorten).</li><li><strong>Krankheitsfall:</strong> das aktuelle Quartal und die <strong>drei folgenden Quartale</strong> für dieselbe Gebührenordnungsposition (wichtig für Leistungen, die nur einmal im Krankheitsfall abrechenbar sind).</li></ul><p>Die <strong>Versichertenpauschale</strong> (Hausarzt) wird einmal im Behandlungsfall abgerechnet. Am Quartalsende wird die Abrechnung elektronisch an die KV übermittelt; Abgabefristen beachten.</p><p><strong>Überweisung (Muster 6):</strong> mit Auftrag (z. B. Definitionsauftrag, Konsiliaruntersuchung, Mit- oder Weiterbehandlung).</p>",
      merke: "Krankheitsfall = vier Quartale (das aktuelle plus drei)." }
  ],
  karten: [
    ["Vorteil der Kombination aus Bestellsystem und Akutsprechstunde?", "Planbarkeit für Termine und trotzdem Platz für akut Erkrankte."],
    ["Welche Rufnummer haben die Terminservicestellen?", "116117."],
    ["Nenne die Teamphasen nach Tuckman.", "Forming, Storming, Norming, Performing, Adjourning."],
    ["Was passiert mit Aufgaben, die dringend, aber nicht wichtig sind?", "Delegieren."],
    ["Wofür steht PDCA?", "Plan, Do, Check, Act."],
    ["Wer schreibt QM in Arztpraxen vor?", "Der G-BA mit seiner Qualitätsmanagement-Richtlinie."],
    ["Was ist ein Behandlungsfall?", "Alle Behandlungen eines Patienten in derselben Praxis im selben Quartal zulasten derselben Kasse."],
    ["Wie lang ist ein Krankheitsfall?", "Das aktuelle und die drei nachfolgenden Quartale."]
  ],
  mc: [
    { q: "Welcher Nachteil gehört typisch zur reinen offenen Sprechstunde?", o: ["Keine Akutpatienten möglich", "Lange und schwer planbare Wartezeiten", "Zu viele Terminabsagen", "Hoher Aufwand für die Terminvergabe"], a: 1, e: "Ohne Termine kommen viele Patienten gleichzeitig. Wartezeiten sind kaum planbar." },
    { q: "In welcher Teamphase entstehen vor allem Konflikte über Rollen und Positionen?", o: ["Forming", "Storming", "Norming", "Performing"], a: 1, e: "In der Storming-Phase werden Positionen ausgehandelt." },
    { q: "Welche Aussage ist eine gute Feedback-Formulierung?", o: ["„Du bist immer unpünktlich.“", "„Mir ist aufgefallen, dass du diese Woche dreimal später kamst. Dadurch musste ich den Empfang allein machen.“", "„Alle sagen, dass du faul bist.“", "„Das war mal wieder typisch.“"], a: 1, e: "Gutes Feedback beschreibt konkretes Verhalten und seine Wirkung, ohne Verallgemeinerung." },
    { q: "Eine Aufgabe ist wichtig, aber nicht dringend. Wie gehst du nach der Eisenhower-Matrix vor?", o: ["Sofort erledigen", "Terminieren", "Delegieren", "Streichen"], a: 1, e: "B-Aufgaben werden fest eingeplant." },
    { q: "Wofür steht das „C“ im PDCA-Zyklus?", o: ["Change", "Control/Check", "Communicate", "Create"], a: 1, e: "Check: Das Ergebnis wird überprüft." },
    { q: "Welches QM-System wurde speziell für Arztpraxen von KBV und KVen entwickelt?", o: ["ISO 14001", "QEP", "EFQM", "HACCP"], a: 1, e: "QEP – Qualität und Entwicklung in Praxen." },
    { q: "Ein Patient kommt im selben Quartal dreimal in die Hausarztpraxis, immer mit derselben Kasse. Wie oft wird die Versichertenpauschale abgerechnet?", o: ["Gar nicht", "Einmal", "Zweimal", "Dreimal"], a: 1, e: "Die Versichertenpauschale ist einmal im Behandlungsfall abrechenbar." },
    { q: "Welcher Zeitraum bildet einen Krankheitsfall?", o: ["Ein Quartal", "Zwei Quartale", "Das aktuelle und die drei folgenden Quartale", "Ein Kalenderjahr von Januar bis Dezember"], a: 2, e: "Der Krankheitsfall umfasst das aktuelle und die drei nachfolgenden Kalendervierteljahre." },
    { q: "Ein Anrufer schildert starke Brustschmerzen und Atemnot. Was tust du?", o: ["Termin für morgen früh vergeben", "Rückruf durch den Arzt am Nachmittag notieren", "Sofort den Notruf 112 empfehlen bzw. veranlassen und den Arzt informieren", "Auf die offene Sprechstunde verweisen"], a: 2, e: "Bei Verdacht auf einen lebensbedrohlichen Notfall zählt jede Minute." },
    { q: "Welches Formular dient der Überweisung an einen Facharzt?", o: ["Muster 1", "Muster 6", "Muster 13", "Muster 16"], a: 1, e: "Muster 6 ist der Überweisungsschein." }
  ],
  fall: [
    { q: "In deiner Praxis beschweren sich Patienten häufig über lange Wartezeiten am Montagvormittag. Entwickle mithilfe des PDCA-Zyklus einen Verbesserungsvorschlag.", p: 20, l: "<p><strong>Plan (6 P.):</strong> Ursachen analysieren (viele Akutpatienten nach dem Wochenende, zu wenig Puffer, Rezeptanfragen am Telefon). Ziel festlegen, z. B. Wartezeit unter 30 Minuten. Maßnahmen: Akutzeitfenster, Rezeptbestellung online, zusätzliche Kraft am Montag.</p><p><strong>Do (4 P.):</strong> Maßnahmen für einen festgelegten Zeitraum umsetzen, Team informieren.</p><p><strong>Check (5 P.):</strong> Wartezeiten messen, Patientenbefragung, Beschwerden zählen, mit Ausgangslage vergleichen.</p><p><strong>Act (5 P.):</strong> Erfolgreiche Maßnahmen als Standard ins QM-Handbuch aufnehmen, sonst nachbessern und den Zyklus wiederholen.</p>" },
    { q: "Ordne folgende Aufgaben der Eisenhower-Matrix zu und begründe kurz: (1) Notfallkoffer-Kontrolle ist heute fällig, (2) Werbebroschüren eines Vertreters sortieren, (3) Telefon klingelt dauerhaft, du bist mit einem Patienten beschäftigt, (4) neue Hygieneunterweisung für das Team vorbereiten (in drei Wochen).", p: 20, l: "<ul><li>(1) A – wichtig und dringend: Sicherheit der Patienten, heute fällig. 5 P.</li><li>(2) D – weder wichtig noch dringend: weglassen bzw. entsorgen. 5 P.</li><li>(3) C – dringend, aber für dich gerade nicht wichtig: an Kollegin delegieren bzw. Anrufbeantworter. 5 P.</li><li>(4) B – wichtig, nicht dringend: fest terminieren. 5 P.</li></ul>" }
  ]
},
{
  id: 8, jahr: 2, std: 60,
  titel: "Patienten bei diagnostischen und therapeutischen Maßnahmen der Erkrankungen des Urogenitalsystems begleiten",
  bereiche: ["Behandlungsassistenz", "Abrechnung"],
  intro: "Nieren, Harnwege und Geschlechtsorgane: Du lernst Aufbau und Funktion, die Urinuntersuchung, häufige Erkrankungen, Schwangerschaft und Verhütung sowie die gesetzlichen Krebsfrüherkennungsuntersuchungen.",
  ziele: [
    "Aufgaben der Niere und den Weg des Harns beschreiben",
    "Mittelstrahlurin gewinnen und einen Urin-Teststreifen auswerten",
    "Harnwegsinfekt, Pyelonephritis, Nierensteine und Prostataerkrankungen unterscheiden",
    "Zyklus, Schwangerschaftsnachweis und Verhütungsmethoden erklären",
    "Krebsfrüherkennung für Frauen und Männer nach Alter zuordnen"
  ],
  kapitel: [
    { t: "Niere und Harnwege",
      h: "<p><strong>Aufgaben der Niere:</strong></p><ul><li>Ausscheidung harnpflichtiger Stoffe (Harnstoff, Harnsäure, Kreatinin, Medikamente)</li><li>Regulation von Wasser-, Elektrolyt- und Säure-Basen-Haushalt</li><li>Blutdruckregulation (Renin)</li><li>Bildung von Erythropoetin (Blutbildung) und Aktivierung von Vitamin D</li></ul><p>Die funktionelle Einheit ist das <strong>Nephron</strong>. In den Nierenkörperchen werden täglich rund <strong>180 Liter Primärharn</strong> filtriert, daraus entstehen durch Rückresorption ca. <strong>1,5 Liter Endharn</strong>.</p><p><strong>Weg des Harns:</strong> Niere → Nierenbecken → Harnleiter → Harnblase → Harnröhre.</p><p>Die Nierenfunktion wird mit Kreatinin im Blut und der geschätzten glomerulären Filtrationsrate (<strong>eGFR</strong>) beurteilt.</p>",
      merke: "180 Liter filtriert, 1,5 Liter ausgeschieden." },
    { t: "Urindiagnostik",
      h: "<p><strong>Mittelstrahlurin:</strong> Hände waschen, Genitalbereich reinigen (Frauen Schamlippen spreizen, Männer Vorhaut zurückziehen), erste Portion in die Toilette, mittlere Portion in den Becher, Rest in die Toilette. Ideal ist der erste Morgenurin.</p><p>Urin innerhalb von <strong>2 Stunden</strong> untersuchen oder gekühlt lagern, da sich Bakterien sonst vermehren.</p><p><strong>Teststreifen (Beispiele):</strong></p><table><tbody><tr><td>Leukozyten</td><td>Hinweis auf Entzündung bzw. Infekt</td></tr><tr><td>Nitrit</td><td>Hinweis auf nitritbildende Bakterien (z. B. E. coli)</td></tr><tr><td>Eiweiß</td><td>Hinweis auf Nierenschädigung</td></tr><tr><td>Glukose</td><td>Hinweis auf erhöhten Blutzucker (Diabetes)</td></tr><tr><td>Blut</td><td>z. B. Infekt, Steine, Tumoren, Menstruation</td></tr><tr><td>Ketone</td><td>z. B. Entgleisung bei Diabetes, Fasten</td></tr></tbody></table><p>Weitere Untersuchungen: Urinsediment (Mikroskop), Urinkultur mit Antibiogramm, Schwangerschaftstest (hCG).</p>",
      merke: "Ein negativer Nitrit-Test schließt einen Harnwegsinfekt nicht aus." },
    { t: "Erkrankungen von Niere und Harnwegen",
      h: "<table><thead><tr><th>Erkrankung</th><th>Kennzeichen</th></tr></thead><tbody><tr><td>Zystitis (Blasenentzündung)</td><td>Brennen beim Wasserlassen, häufiger Harndrang mit kleinen Mengen; Frauen häufiger wegen kurzer Harnröhre</td></tr><tr><td>Pyelonephritis (Nierenbeckenentzündung)</td><td>Fieber, Schüttelfrost, Flankenschmerz, Krankheitsgefühl</td></tr><tr><td>Nierensteine</td><td>kolikartige, wellenförmige Schmerzen in Flanke bis Leiste, Blut im Urin</td></tr><tr><td>Niereninsuffizienz</td><td>Abnahme der Nierenfunktion, erhöhtes Kreatinin, verminderte eGFR; im Endstadium Dialyse</td></tr><tr><td>Benigne Prostatahyperplasie</td><td>gutartige Vergrößerung; schwacher Harnstrahl, nächtlicher Harndrang, Restharn</td></tr><tr><td>Prostatakarzinom</td><td>häufigster Krebs beim Mann, lange beschwerdefrei</td></tr></tbody></table><p>Fachbegriffe: <strong>Dysurie</strong> (schmerzhaftes Wasserlassen), <strong>Pollakisurie</strong> (häufiges Wasserlassen kleiner Mengen), <strong>Hämaturie</strong> (Blut im Urin), <strong>Nykturie</strong> (nächtliches Wasserlassen), <strong>Oligurie/Anurie</strong> (wenig/kein Urin).</p>",
      merke: "Zystitis plus Fieber und Flankenschmerz = Verdacht auf Pyelonephritis." },
    { t: "Geschlechtsorgane, Zyklus und Schwangerschaft",
      h: "<p><strong>Weiblicher Zyklus</strong> (ca. 28 Tage): Menstruation, Aufbauphase der Gebärmutterschleimhaut, <strong>Eisprung</strong> etwa in der Zyklusmitte (ca. 14. Tag bei 28 Tagen), Gelbkörperphase.</p><p><strong>Schwangerschaftsnachweis:</strong> Das Hormon <strong>hCG</strong> wird im Urin oder Blut nachgewiesen. Die Schwangerschaft wird ab dem ersten Tag der letzten Regel gerechnet und dauert etwa 40 Wochen. Untersuchungen werden im <strong>Mutterpass</strong> dokumentiert.</p><p><strong>Verhütung:</strong> Die Sicherheit wird mit dem <strong>Pearl-Index</strong> angegeben (Schwangerschaften pro 100 Frauen in einem Jahr). Je kleiner, desto sicherer. Beispiele: Pille, Spirale, Kondom (schützt zusätzlich vor sexuell übertragbaren Infektionen).</p><p><strong>Sexuell übertragbare Infektionen:</strong> Chlamydien (oft symptomlos; Screening für junge Frauen bis 25 Jahre), Gonorrhö, Syphilis, HPV (Impfung für Mädchen und Jungen von 9 bis 14 Jahren, Nachholen bis 17).</p>",
      merke: "Pearl-Index: je niedriger, desto sicherer." },
    { t: "Krebsfrüherkennung (GKV)",
      h: "<table><thead><tr><th>Für</th><th>Ab Alter</th><th>Untersuchung</th></tr></thead><tbody><tr><td>Frauen</td><td>20</td><td>jährlich Genitaluntersuchung</td></tr><tr><td>Frauen</td><td>20–34</td><td>jährlich zytologischer Abstrich (Pap)</td></tr><tr><td>Frauen</td><td>ab 35</td><td>alle 3 Jahre Ko-Test (HPV-Test und Zytologie)</td></tr><tr><td>Frauen</td><td>ab 30</td><td>jährlich Tastuntersuchung der Brust</td></tr><tr><td>Frauen</td><td>50–75</td><td>Mammographie-Screening alle 2 Jahre</td></tr><tr><td>Männer</td><td>ab 45</td><td>jährlich Untersuchung der Prostata (Tastbefund) und äußeren Genitale</td></tr></tbody></table><p>Weitere Früherkennung (Haut, Darm) findest du in LF 9 und LF 11.</p>",
      merke: "Mammographie-Screening: 50 bis 75 Jahre, alle 2 Jahre." }
  ],
  karten: [
    ["Wie viel Primärharn bilden die Nieren pro Tag?", "Rund 180 Liter (daraus ca. 1,5 Liter Endharn)."],
    ["Welches Hormon bildet die Niere für die Blutbildung?", "Erythropoetin (EPO)."],
    ["Was bedeutet Pollakisurie?", "Häufiges Wasserlassen kleiner Mengen."],
    ["Warum bekommen Frauen häufiger Blasenentzündungen?", "Sie haben eine kürzere Harnröhre."],
    ["Was weist ein Schwangerschaftstest nach?", "Das Hormon hCG."],
    ["Was gibt der Pearl-Index an?", "Wie viele von 100 Frauen in einem Jahr trotz Verhütungsmethode schwanger werden."],
    ["Ab welchem Alter haben Männer Anspruch auf jährliche Prostata-Tastuntersuchung?", "Ab 45 Jahren."],
    ["Innerhalb welcher Zeit soll Urin untersucht werden?", "Innerhalb von 2 Stunden, sonst kühlen."]
  ],
  mc: [
    { q: "Welche Aufgabe hat die Niere NICHT?", o: ["Bildung von Erythropoetin", "Blutdruckregulation über Renin", "Bildung von Insulin", "Ausscheidung von Harnstoff"], a: 2, e: "Insulin wird in den Langerhans-Inseln der Bauchspeicheldrüse gebildet." },
    { q: "In welcher Reihenfolge fließt der Harn?", o: ["Niere – Harnröhre – Blase – Harnleiter", "Niere – Nierenbecken – Harnleiter – Blase – Harnröhre", "Niere – Blase – Harnleiter – Harnröhre", "Nierenbecken – Niere – Blase – Harnleiter"], a: 1, e: "Niere, Nierenbecken, Harnleiter, Harnblase, Harnröhre." },
    { q: "Warum soll bei der Uringewinnung die erste Portion verworfen werden?", o: ["Sie ist zu konzentriert", "Sie enthält Keime aus der Harnröhre", "Sie enthält zu wenig Eiweiß", "Damit genug Urin in den Becher passt"], a: 1, e: "Die erste Portion spült Keime aus der Harnröhre und würde das Ergebnis verfälschen." },
    { q: "Ein positiver Nitrit-Nachweis im Urin weist hin auf …", o: ["Diabetes mellitus", "eine Schwangerschaft", "bestimmte Bakterien im Urin", "eine Nierenschädigung durch Eiweiß"], a: 2, e: "Viele Harnwegserreger wie E. coli wandeln Nitrat in Nitrit um." },
    { q: "Was passiert mit Urin, der mehrere Stunden ungekühlt steht?", o: ["Nichts, er bleibt stabil", "Bakterien vermehren sich, Ergebnisse werden verfälscht", "Er wird steril", "Glukosewerte steigen an"], a: 1, e: "Bakterien vermehren sich und verbrauchen z. B. Glukose; das Ergebnis wird unbrauchbar." },
    { q: "Welche Symptome sprechen am ehesten für eine Pyelonephritis?", o: ["Brennen beim Wasserlassen ohne Fieber", "Fieber, Schüttelfrost und Flankenschmerz", "Nächtlicher Harndrang beim älteren Mann", "Juckreiz im Genitalbereich"], a: 1, e: "Fieber und Flankenschmerz zeigen, dass die Entzündung die Niere erreicht hat." },
    { q: "Was beschreibt eine Nykturie?", o: ["Schmerzhaftes Wasserlassen", "Blut im Urin", "Nächtliches Wasserlassen", "Keine Urinausscheidung"], a: 2, e: "Nykturie heißt nächtliches Wasserlassen, typisch bei Prostatavergrößerung oder Herzschwäche." },
    { q: "Welcher Wert misst die Sicherheit einer Verhütungsmethode?", o: ["BMI", "Pearl-Index", "Apgar-Score", "eGFR"], a: 1, e: "Der Pearl-Index gibt die Versagerquote pro 100 Frauenjahre an." },
    { q: "Ab welchem Alter bekommen Frauen im Rahmen der Krebsfrüherkennung alle 3 Jahre einen Ko-Test?", o: ["20", "30", "35", "50"], a: 2, e: "Ab 35 Jahren: HPV-Test und Zytologie alle 3 Jahre." },
    { q: "Für welche Altersgruppe gilt das Mammographie-Screening?", o: ["30–50 Jahre", "40–60 Jahre", "50–75 Jahre", "ab 65 Jahre"], a: 2, e: "Frauen von 50 bis 75 Jahren werden alle 2 Jahre eingeladen." }
  ],
  fall: [
    { q: "Frau Jensen (29) kommt mit Brennen beim Wasserlassen und ständigem Harndrang. Der Arzt bittet dich um eine Urinprobe und einen Teststreifen. Erkläre der Patientin die Gewinnung von Mittelstrahlurin und beschreibe, welche Teststreifenergebnisse zu einem Harnwegsinfekt passen.", p: 20, l: "<p><strong>Anleitung (10 P.):</strong> Hände waschen, Becher beschriften, Schamlippen spreizen und Harnröhrenausgang reinigen, erste Portion in die Toilette, mittlere Portion in den Becher (ca. halb voll), Rest in die Toilette, Becher verschließen, nicht innen berühren, sofort abgeben.</p><p><strong>Teststreifen (10 P.):</strong> Leukozyten positiv, Nitrit positiv (kann auch negativ sein), ggf. Blut und Eiweiß leicht positiv. Ablesezeit beachten, Befund dokumentieren und dem Arzt vorlegen; ggf. Urinkultur nach Anordnung.</p>" },
    { q: "Herr Brandt (67) erzählt am Empfang, er müsse nachts dreimal zur Toilette und der Harnstrahl sei schwach. Er war seit Jahren nicht mehr bei einer Vorsorge. Nenne die vermutete Ursache, erkläre zwei Fachbegriffe für seine Beschwerden und informiere ihn über seinen Anspruch auf Krebsfrüherkennung.", p: 20, l: "<p><strong>Ursache (6 P.):</strong> Verdacht auf gutartige Prostatavergrößerung (BPH); ein Prostatakarzinom muss ärztlich ausgeschlossen werden.</p><p><strong>Fachbegriffe (6 P.):</strong> Nykturie (nächtliches Wasserlassen), Restharn bzw. abgeschwächter Harnstrahl, ggf. Pollakisurie.</p><p><strong>Früherkennung (8 P.):</strong> Männer ab 45 haben jährlich Anspruch auf Tastuntersuchung der Prostata und Untersuchung des äußeren Genitales; zusätzlich Gesundheitsuntersuchung (Check-up) alle 3 Jahre, Hautkrebs-Screening, Darmkrebsfrüherkennung. Termin anbieten.</p>" }
  ]
}
]);
