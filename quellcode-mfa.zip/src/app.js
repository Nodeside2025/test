(function () {
  "use strict";
  var LF = window.LF.slice().sort(function (a, b) { return a.id - b.id; });
  var EXAM_DATE = new Date("2026-11-24T08:00:00+01:00");
  var KEY = "mfa-lernfeld-kompass-v1";
  var app = document.getElementById("app");

  /* ---------- Speicher (nur dieses Gerät) ---------- */
  var state = { read: {}, best: {}, notes: {}, cards: {}, trainings: [] };
  try {
    var raw = localStorage.getItem(KEY);
    if (raw) { var p = JSON.parse(raw); for (var k in state) if (p[k]) state[k] = p[k]; }
  } catch (e) { /* Speicher nicht verfügbar */ }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }

  /* ---------- Helfer ---------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function lfById(id) { for (var i = 0; i < LF.length; i++) if (LF[i].id === id) return LF[i]; return null; }
  function note(points) {
    var p = Math.round(points);
    if (p >= 92) return { n: 1, t: "sehr gut" };
    if (p >= 81) return { n: 2, t: "gut" };
    if (p >= 67) return { n: 3, t: "befriedigend" };
    if (p >= 50) return { n: 4, t: "ausreichend" };
    if (p >= 30) return { n: 5, t: "mangelhaft" };
    return { n: 6, t: "ungenügend" };
  }
  function readCount(lf) { return (state.read["lf" + lf.id] || []).length; }
  function toast(msg) {
    var t = $("#toast"); t.textContent = msg; t.hidden = false;
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.hidden = true; }, 2200);
  }
  function wrapTables(html) { return html.replace(/<table/g, "<div class='tbl'><table").replace(/<\/table>/g, "</table></div>"); }
  function setNav(name) { $$(".nav a").forEach(function (a) { if (a.getAttribute("data-nav") === name) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); }); }
  function daysToExam() { return Math.ceil((EXAM_DATE - new Date()) / 86400000); }

  /* ---------- Router ---------- */
  function route() {
    var h = (location.hash || "#start").slice(1);
    var m = /^lf(\d+)(?:-(lernen|karten|test|notizen))?$/.exec(h);
    window.scrollTo(0, 0);
    if (m && lfById(+m[1])) { setNav("start"); renderLF(lfById(+m[1]), m[2] || "lernen"); }
    else if (h === "training") { setNav("training"); renderTraining(); }
    else if (h === "pruefung") { setNav("pruefung"); renderInfo(); }
    else { setNav("start"); renderHome(); }
  }
  window.addEventListener("hashchange", route);

  /* ---------- Übersicht ---------- */
  function renderHome() {
    var totalK = 0, doneK = 0, tests = 0;
    LF.forEach(function (lf) { totalK += lf.kapitel.length; doneK += readCount(lf); if (state.best["lf" + lf.id] != null) tests++; });
    var pct = Math.round(doneK / totalK * 100);
    var d = daysToExam();
    var examHtml = d > 0
      ? "<div class='eyebrow'>Schriftliche Abschlussprüfung</div><div class='days'>" + d + " Tage</div><p>bis zum 24. November 2026 an der Akademie der Ärztekammer SH in Bad Segeberg. Nächste Anmeldefristen: 15. Februar und 31. August.</p>"
      : "<div class='eyebrow'>Prüfungstermine</div><p>Die aktuellen Termine veröffentlicht die Ärztekammer Schleswig-Holstein auf aeksh.de. Anmeldefristen: 15. Februar (Sommer) und 31. August (Winter).</p>";

    var html = "<section class='hero'><div><div class='eyebrow'>12 Lernfelder · 3 Ausbildungsjahre · 840 Unterrichtsstunden</div>" +
      "<h1>Wähle ein Lernfeld und arbeite dich Kapitel für Kapitel zur Übungsarbeit.</h1>" +
      "<p class='lead'>Jedes Lernfeld folgt dem KMK-Rahmenlehrplan für Medizinische Fachangestellte: erst verstehen, dann mit Karteikarten wiederholen, zum Schluss die Übungsarbeit mit Note nach dem 100-Punkte-Schlüssel.</p>" +
      "<div class='overall'><div class='bar' aria-hidden='true'><i style='width:" + pct + "%'></i></div><span class='mono' style='font-size:14px'>" + doneK + "/" + totalK + " Kapitel · " + tests + "/12 Arbeiten</span></div></div>" +
      "<aside class='exam'>" + examHtml + "</aside></section>";

    [1, 2, 3].forEach(function (j) {
      var list = LF.filter(function (l) { return l.jahr === j; });
      var hours = list.reduce(function (s, l) { return s + l.std; }, 0);
      html += "<section class='year'><div class='year-head'><h2>" + j + ". Ausbildungsjahr</h2><span class='mono'>LF " + list[0].id + "–" + list[list.length - 1].id + " · " + hours + " Std.</span></div><div class='grid'>";
      list.forEach(function (lf) {
        var rc = readCount(lf), kc = lf.kapitel.length, best = state.best["lf" + lf.id];
        var pill = best != null ? "<span class='pill g" + note(best).n + "'>Übungsarbeit: Note " + note(best).n + " · " + best + " P.</span>" : "<span class='pill open'>Übungsarbeit offen</span>";
        html += "<a class='card' href='#lf" + lf.id + "'><div class='card-top'><span class='lfnum'>LF " + pad(lf.id) + "</span><span class='mono' style='font-size:12px;color:var(--muted)'>" + lf.std + " Std.</span></div>" +
          "<h3>" + esc(lf.titel) + "</h3><div class='chips'>" + lf.bereiche.map(function (b) { return "<span class='chip'>" + b + "</span>"; }).join("") + "</div>" +
          "<div class='card-foot'><div class='prog'><div class='bar'><i style='width:" + Math.round(rc / kc * 100) + "%'></i></div><span class='mono'>" + rc + "/" + kc + "</span></div>" + pill + "</div></a>";
      });
      html += "</div></section>";
    });
    html += footer();
    app.innerHTML = html;
  }

  function footer() {
    return "<p class='footer'>Lerninhalte eigenständig formuliert nach dem KMK-Rahmenlehrplan Medizinische Fachangestellte (2005) und öffentlichen Informationen der Ärztekammer Schleswig-Holstein. Ersetzt nicht Unterricht, Lehrbuch und ärztliche Anweisung. Dein Fortschritt wird nur in diesem Browser gespeichert.</p>" +
      "<a class='made-by' href='https://www.nodeside.eu' target='_blank' rel='noopener'><span>Entwickelt von</span><img src='" + window.MFA_LOGO_FULL + "' alt='Nodeside – www.nodeside.eu'></a>";
  }

  /* ---------- Lernfeld ---------- */
  function renderLF(lf, tab) {
    var tabs = [["lernen", "Lernen"], ["karten", "Karteikarten"], ["test", "Übungsarbeit"], ["notizen", "Notizen"]];
    var html = "<a class='back' href='#start'>← Alle Lernfelder</a>" +
      "<header class='lf-head'><div class='lf-big' aria-hidden='true'>" + pad(lf.id) + "</div><div><div class='eyebrow'>Lernfeld " + lf.id + " · " + lf.jahr + ". Ausbildungsjahr</div><h1>" + esc(lf.titel) + "</h1></div>" +
      "<div class='lf-meta'><span class='mono'>" + lf.std + " Unterrichtsstunden</span>" + lf.bereiche.map(function (b) { return "<span class='chip'>" + b + "</span>"; }).join("") + "</div></header>" +
      "<div class='tabs' role='tablist'>" +
      tabs.map(function (t) { return "<button role='tab' aria-selected='" + (t[0] === tab) + "' data-tab='" + t[0] + "'>" + t[1] + "</button>"; }).join("") +
      "</div><div id='pane'></div>";
    app.innerHTML = html;
    $$(".tabs button").forEach(function (b) {
      b.addEventListener("click", function () { location.hash = "lf" + lf.id + (b.dataset.tab === "lernen" ? "" : "-" + b.dataset.tab); });
    });
    var pane = $("#pane");
    if (tab === "lernen") paneLernen(lf, pane);
    else if (tab === "karten") paneKarten(lf, pane);
    else if (tab === "test") paneTest(lf, pane);
    else paneNotizen(lf, pane);
  }

  function paneLernen(lf, pane) {
    var key = "lf" + lf.id, done = state.read[key] || [];
    var html = "<div class='cols'><div><p class='intro'>" + esc(lf.intro) + "</p>";
    lf.kapitel.forEach(function (k, i) {
      var isDone = done.indexOf(i) > -1;
      html += "<details class='kap'" + (i === 0 && !isDone ? " open" : "") + "><summary><span class='kap-n'>" + lf.id + "." + (i + 1) + "</span><span class='kap-t'>" + esc(k.t) + "</span><span class='kap-s" + (isDone ? " done" : "") + "' aria-label='" + (isDone ? "verstanden" : "offen") + "'>✓</span></summary>" +
        "<div class='kap-body'>" + wrapTables(k.h) + (k.merke ? "<div class='merke'><b>Merke</b><span>" + esc(k.merke) + "</span></div>" : "") +
        "<div class='row' style='margin-top:14px'><button class='btn small" + (isDone ? "" : " primary") + "' data-k='" + i + "'>" + (isDone ? "Als offen markieren" : "Verstanden – weiter") + "</button></div></div></details>";
    });
    html += "<div class='row' style='margin-top:20px'><a class='btn' href='#lf" + lf.id + "-karten'>Mit Karteikarten wiederholen</a><a class='btn primary' href='#lf" + lf.id + "-test'>Zur Übungsarbeit</a></div></div>" +
      "<aside class='aside'><div class='eyebrow'>Das lernst du</div><ul>" + lf.ziele.map(function (z) { return "<li>" + esc(z) + "</li>"; }).join("") + "</ul></aside></div>";
    pane.innerHTML = html;
    $$("button[data-k]", pane).forEach(function (b) {
      b.addEventListener("click", function () {
        var i = +b.dataset.k, arr = state.read[key] || [], pos = arr.indexOf(i);
        if (pos > -1) arr.splice(pos, 1); else arr.push(i);
        state.read[key] = arr; save();
        var det = b.closest("details"), next = det.nextElementSibling;
        var open = pos === -1;
        paneLernen(lf, pane);
        if (open) { var all = $$("details.kap", pane); all.forEach(function (d) { d.open = false; }); if (all[i + 1]) { all[i + 1].open = true; all[i + 1].scrollIntoView({ block: "start", behavior: "smooth" }); } }
        else { $$("details.kap", pane)[i].open = true; }
      });
    });
  }

  function paneKarten(lf, pane) {
    var deck = shuffle(lf.karten.map(function (c, i) { return i; }));
    var idx = 0, known = 0, again = [];
    function draw() {
      if (idx >= deck.length) {
        var rec = state.cards["lf" + lf.id] = { known: known, total: lf.karten.length, at: Date.now() }; save();
        pane.innerHTML = "<div class='paper flash-wrap'><div class='eyebrow'>Durchgang beendet</div><h2 style='margin-top:6px'>" + known + " von " + deck.length + " gewusst</h2>" +
          "<p class='lead'>" + (again.length ? "Wiederhole die " + again.length + " Karten, die noch nicht sitzen." : "Alles gewusst. Zeit für die Übungsarbeit.") + "</p><div class='row' style='margin-top:16px'>" +
          (again.length ? "<button class='btn primary' id='again'>Nur offene Karten</button>" : "") + "<button class='btn' id='restart'>Alle Karten neu</button><a class='btn' href='#lf" + lf.id + "-test'>Zur Übungsarbeit</a></div></div>";
        var a = $("#again", pane); if (a) a.onclick = function () { deck = shuffle(again); again = []; idx = 0; known = 0; draw(); };
        $("#restart", pane).onclick = function () { deck = shuffle(lf.karten.map(function (c, i) { return i; })); again = []; idx = 0; known = 0; draw(); };
        return;
      }
      var c = lf.karten[deck[idx]];
      pane.innerHTML = "<div class='flash-wrap'><div class='row' style='justify-content:space-between;margin-bottom:12px'><span class='mono' style='color:var(--muted)'>Karte " + (idx + 1) + " / " + deck.length + "</span><span class='mono' style='color:var(--muted)'>gewusst: " + known + "</span></div>" +
        "<button class='flash' id='flash' aria-label='Karte umdrehen'><div class='flash-inner'><div class='face'><span class='eyebrow'>Frage · tippen zum Umdrehen</span><p>" + esc(c[0]) + "</p></div><div class='face back'><span class='eyebrow'>Antwort</span><p>" + esc(c[1]) + "</p></div></div></button>" +
        "<div class='row' style='margin-top:16px'><button class='btn' id='no' disabled>Nochmal</button><button class='btn primary' id='yes' disabled>Gewusst</button></div></div>";
      var f = $("#flash", pane);
      f.onclick = function () { f.classList.toggle("flip"); $("#no", pane).disabled = false; $("#yes", pane).disabled = false; };
      $("#yes", pane).onclick = function () { known++; idx++; draw(); };
      $("#no", pane).onclick = function () { again.push(deck[idx]); idx++; draw(); };
    }
    draw();
  }

  function paneNotizen(lf, pane) {
    var key = "lf" + lf.id;
    pane.innerHTML = "<div class='paper' style='max-width:760px'><h2>Meine Notizen</h2><p class='lead'>Halte hier fest, was dir im Unterricht wichtig war, oder notiere die passenden Seiten aus deinem Lehrbuch, zum Beispiel aus „… in der Arztpraxis“.</p>" +
      "<label for='notes-" + lf.id + "' class='eyebrow' style='display:block;margin:18px 0 6px'>Notizen zu Lernfeld " + lf.id + "</label><textarea id='notes-" + lf.id + "' style='min-height:260px' placeholder='z. B. Behandlungsassistenz, S. 112–130: Wirbelsäule und Gelenke'></textarea><p class='mono' id='saved' style='font-size:12px;color:var(--muted)'>Wird automatisch gespeichert.</p></div>";
    var ta = $("textarea", pane); ta.value = state.notes[key] || "";
    var t; ta.addEventListener("input", function () { clearTimeout(t); t = setTimeout(function () { state.notes[key] = ta.value; save(); $("#saved", pane).textContent = "Gespeichert " + new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }); }, 400); });
  }

  /* ---------- Übungsarbeit ---------- */
  function paneTest(lf, pane) {
    var key = "lf" + lf.id, best = state.best[key];
    var mcPts = 60 / lf.mc.length;
    pane.innerHTML = "<div class='paper' style='max-width:820px'><div class='eyebrow'>Übungsarbeit · Lernfeld " + lf.id + "</div><h2 style='margin-top:6px'>" + esc(lf.titel) + "</h2>" +
      "<div class='parts'><div class='part'><div class='mono'>60 P.</div><b>Teil A</b><br><span style='color:var(--muted);font-size:15px'>" + lf.mc.length + " Multiple-Choice-Aufgaben, je eine richtige Antwort, wie in der schriftlichen Prüfung</span></div>" +
      "<div class='part'><div class='mono'>40 P.</div><b>Teil B</b><br><span style='color:var(--muted);font-size:15px'>" + lf.fall.length + " Fallaufgaben aus dem Praxisalltag, Bewertung mit Musterlösung</span></div>" +
      "<div class='part'><div class='mono'>ca. 45 Min.</div><b>Bearbeitungszeit</b><br><span style='color:var(--muted);font-size:15px'>Note nach dem 100-Punkte-Schlüssel</span></div></div>" +
      (best != null ? "<p>Dein bestes Ergebnis bisher: <span class='pill g" + note(best).n + "'>Note " + note(best).n + " · " + best + " Punkte</span></p>" : "") +
      "<button class='btn primary' id='start'>Übungsarbeit beginnen</button></div>";
    $("#start", pane).onclick = function () { runTest(lf, pane, mcPts); };
  }

  function runTest(lf, pane, mcPts) {
    var orders = lf.mc.map(function (q) { return shuffle(q.o.map(function (o, i) { return i; })); });
    var html = "<form id='exam' class='paper' style='max-width:820px' novalidate><div class='eyebrow'>Teil A · Multiple Choice · je " + (Math.round(mcPts * 10) / 10) + " Punkte</div>";
    lf.mc.forEach(function (q, qi) {
      html += "<fieldset class='q' data-q='" + qi + "'><legend><span class='qn'>A" + (qi + 1) + "</span><span>" + esc(q.q) + "</span></legend><div class='opts'>";
      orders[qi].forEach(function (oi) {
        html += "<label class='opt' data-o='" + oi + "'><input type='radio' name='q" + qi + "' id='q" + lf.id + "-" + qi + "-" + oi + "' value='" + oi + "'><span>" + esc(q.o[oi]) + "</span></label>";
      });
      html += "</div></fieldset>";
    });
    html += "</form><div class='paper' style='max-width:820px'><div class='eyebrow'>Teil B · Fallaufgaben</div>";
    lf.fall.forEach(function (f, fi) {
      html += "<div class='q' style='padding:18px 0;border-top:" + (fi ? "1px solid var(--line)" : "0") + "' data-f='" + fi + "'><p style='margin:0 0 10px'><span class='qn' style='margin-right:10px'>B" + (fi + 1) + "</span><b>" + esc(f.q) + "</b> <span class='mono' style='color:var(--muted);font-size:13px'>(" + f.p + " P.)</span></p>" +
        "<label class='eyebrow' for='fa" + lf.id + "-" + fi + "' style='display:block;margin-bottom:6px'>Deine Antwort</label><textarea id='fa" + lf.id + "-" + fi + "' placeholder='Stichpunkte reichen.'></textarea><div class='fall-out'></div></div>";
    });
    html += "</div><div class='sticky-total' id='bar'><span id='status'>Beantworte alle Aufgaben und gib dann ab.</span><button class='btn' id='submit'>Abgeben und auswerten</button></div>";
    pane.innerHTML = html;
    pane.scrollIntoView({ block: "start" });

    var fallPts = lf.fall.map(function () { return null; });
    var mcScore = 0;

    function updateTotal(final) {
      var open = fallPts.filter(function (p) { return p === null; }).length;
      var fp = fallPts.reduce(function (s, p) { return s + (p || 0); }, 0);
      var total = Math.round(mcScore + fp);
      var n = note(total);
      $("#status").innerHTML = open ? "Teil A: " + Math.round(mcScore) + " von 60 P. · Bewerte noch " + open + " Fallaufgabe" + (open > 1 ? "n" : "") + " mit der Musterlösung."
        : "<b>Gesamt: " + total + " von 100 Punkten · Note " + n.n + " (" + n.t + ")</b>";
      var btn = $("#submit");
      if (!open) { btn.textContent = "Ergebnis speichern"; btn.disabled = false; } else { btn.textContent = "Ergebnis speichern"; btn.disabled = true; }
      return total;
    }

    var submitted = false;
    $("#submit").onclick = function () {
      if (!submitted) {
        submitted = true;
        mcScore = 0;
        lf.mc.forEach(function (q, qi) {
          var fs = $("fieldset[data-q='" + qi + "']", pane);
          var chosen = $("input:checked", fs);
          var c = chosen ? +chosen.value : -1;
          $$("input", fs).forEach(function (inp) { inp.disabled = true; });
          $$(".opt", fs).forEach(function (l) {
            var o = +l.dataset.o;
            if (o === q.a) l.classList.add("right");
            else if (o === c) l.classList.add("wrong");
          });
          if (c === q.a) mcScore += mcPts;
          var ex = document.createElement("div"); ex.className = "expl";
          ex.innerHTML = (c === q.a ? "<b class='ok'>Richtig.</b> " : c === -1 ? "<b class='no'>Nicht beantwortet.</b> " : "<b class='no'>Falsch.</b> ") + esc(q.e);
          fs.appendChild(ex);
        });
        lf.fall.forEach(function (f, fi) {
          var box = $("[data-f='" + fi + "'] .fall-out", pane);
          $("[data-f='" + fi + "'] textarea", pane).readOnly = true;
          var steps = [0, 0.25, 0.5, 0.75, 1].map(function (x) { return Math.round(f.p * x); });
          box.innerHTML = "<div class='fall-l'><div class='eyebrow' style='margin-bottom:6px'>Musterlösung</div>" + f.l + "</div>" +
            "<div class='seg' role='group' aria-label='Punkte für B" + (fi + 1) + "'><span style='font-size:14px;margin-right:6px'>Vergleiche ehrlich und vergib Punkte:</span>" +
            steps.map(function (s) { return "<button type='button' aria-pressed='false' data-p='" + s + "'>" + s + "</button>"; }).join("") + "</div>";
          $$(".seg button", box).forEach(function (b) {
            b.onclick = function () { $$(".seg button", box).forEach(function (x) { x.setAttribute("aria-pressed", "false"); }); b.setAttribute("aria-pressed", "true"); fallPts[fi] = +b.dataset.p; updateTotal(); };
          });
        });
        updateTotal();
        var first = $(".fall-out", pane); if (first) first.scrollIntoView({ block: "center", behavior: "smooth" });
        return;
      }
      var total = updateTotal();
      var key = "lf" + lf.id;
      if (state.best[key] == null || total > state.best[key]) state.best[key] = total;
      save();
      var n = note(total);
      var res = document.createElement("div");
      res.className = "result";
      res.innerHTML = "<div class='note'>" + n.n + "</div><div><div class='eyebrow' style='color:inherit;opacity:.7'>Ergebnis Übungsarbeit LF " + lf.id + "</div><b style='font-size:20px'>" + total + " von 100 Punkten · " + n.t + "</b><p>Teil A " + Math.round(mcScore) + "/60 · Teil B " + (total - Math.round(mcScore)) + "/40. " + (total >= 50 ? "Bestanden – die Bestehensgrenze liegt bei 50 Punkten." : "Unter 50 Punkten. Lies die Kapitel mit den falschen Antworten noch einmal.") + "</p>" +
        "<div class='row' style='margin-top:12px'><button class='btn small' id='retry'>Neu schreiben</button><a class='btn small' href='#lf" + lf.id + "'>Zurück zu den Kapiteln</a><a class='btn small' href='#start'>Übersicht</a></div></div>";
      pane.insertBefore(res, pane.firstChild);
      $("#bar").remove();
      res.scrollIntoView({ block: "start", behavior: "smooth" });
      $("#retry").onclick = function () { runTest(lf, pane, mcPts); };
      toast("Ergebnis gespeichert");
    };
  }

  /* ---------- Prüfungstraining ---------- */
  function renderTraining() {
    var last = state.trainings.slice(-5).reverse();
    var html = "<div class='eyebrow'>Gemischtes Training</div><h1>Prüfungstraining</h1><p class='lead'>Multiple-Choice-Fragen aus mehreren Lernfeldern, zufällig gemischt und mit Zeitvorgabe wie in der schriftlichen Prüfung.</p>" +
      "<div class='paper' style='max-width:820px;margin-top:22px'><h2 style='font-size:20px'>Welche Ausbildungsjahre?</h2><div class='row' style='margin-top:12px'>" +
      [1, 2, 3].map(function (j) { return "<label class='toggle'><input type='checkbox' id='tj" + j + "' value='" + j + "' checked> " + j + ". Jahr <span class='mono' style='color:var(--muted);font-size:13px'>LF " + (j * 4 - 3) + "–" + (j * 4) + "</span></label>"; }).join("") +
      "</div><h2 style='font-size:20px;margin-top:22px'>Wie viele Fragen?</h2><div class='row' style='margin-top:12px'>" +
      [20, 30, 40].map(function (n, i) { return "<label class='toggle'><input type='radio' name='tn' id='tn" + n + "' value='" + n + "'" + (i === 1 ? " checked" : "") + "> " + n + " Fragen <span class='mono' style='color:var(--muted);font-size:13px'>" + Math.round(n * 1.5) + " Min.</span></label>"; }).join("") +
      "</div><p style='font-size:15px;color:var(--muted)'>Tipp: Vor der Zwischenprüfung das 1. und 2. Jahr wählen.</p><button class='btn primary' id='go' style='margin-top:6px'>Training starten</button></div>";
    if (last.length) {
      html += "<div class='paper' style='max-width:820px'><h2 style='font-size:20px'>Letzte Trainings</h2><div class='tbl'><table class='tbl-plain' style='margin-top:10px'><thead><tr><th>Datum</th><th>Jahre</th><th>Fragen</th><th>Punkte</th><th>Note</th></tr></thead><tbody>" +
        last.map(function (t) { return "<tr><td class='mono'>" + new Date(t.at).toLocaleDateString("de-DE") + "</td><td>" + t.jahre.join(", ") + "</td><td class='mono'>" + t.n + "</td><td class='mono'>" + t.p + "</td><td><span class='pill g" + note(t.p).n + "'>" + note(t.p).n + "</span></td></tr>"; }).join("") +
        "</tbody></table></div></div>";
    }
    html += footer();
    app.innerHTML = html;
    $("#go").onclick = function () {
      var jahre = [1, 2, 3].filter(function (j) { return $("#tj" + j).checked; });
      if (!jahre.length) { toast("Wähle mindestens ein Ausbildungsjahr."); return; }
      var n = +$("input[name='tn']:checked").value;
      var pool = [];
      LF.forEach(function (lf) { if (jahre.indexOf(lf.jahr) > -1) lf.mc.forEach(function (q) { pool.push({ lf: lf, q: q }); }); });
      runTraining(shuffle(pool).slice(0, Math.min(n, pool.length)), jahre);
    };
  }

  function runTraining(items, jahre) {
    var limit = Math.round(items.length * 1.5) * 60, start = Date.now(), timerId;
    var html = "<div class='row' style='justify-content:space-between'><div><div class='eyebrow'>Prüfungstraining · " + jahre.map(function (j) { return j + ". Jahr"; }).join(", ") + "</div><h1 style='font-size:28px'>" + items.length + " Fragen</h1></div><div class='timer' id='timer' aria-live='off'></div></div>" +
      "<form class='paper' style='max-width:820px;margin-top:18px' id='tr' novalidate>";
    items.forEach(function (it, i) {
      var ord = shuffle(it.q.o.map(function (o, k) { return k; }));
      html += "<fieldset class='q' data-i='" + i + "'><legend><span class='qn'>" + pad(i + 1) + "</span><span>" + esc(it.q.q) + " <span class='chip'>LF " + it.lf.id + "</span></span></legend><div class='opts'>" +
        ord.map(function (k) { return "<label class='opt' data-o='" + k + "'><input type='radio' name='t" + i + "' id='t" + i + "-" + k + "' value='" + k + "'><span>" + esc(it.q.o[k]) + "</span></label>"; }).join("") + "</div></fieldset>";
    });
    html += "</form><div class='sticky-total'><span id='tstat'>0 von " + items.length + " beantwortet</span><button class='btn' id='tsub'>Abgeben</button></div>";
    app.innerHTML = html;
    function tick() {
      var left = limit - Math.floor((Date.now() - start) / 1000);
      var el = $("#timer"); if (!el) { clearInterval(timerId); return; }
      var neg = left < 0, a = Math.abs(left);
      el.textContent = (neg ? "+" : "") + Math.floor(a / 60) + ":" + pad(a % 60) + (neg ? " über der Zeit" : " verbleibend");
      el.style.color = neg ? "var(--bad)" : "var(--muted)";
    }
    tick(); timerId = setInterval(tick, 1000);
    $("#tr").addEventListener("change", function () { $("#tstat").textContent = $$("#tr input:checked").length + " von " + items.length + " beantwortet"; });
    $("#tsub").onclick = function () {
      clearInterval(timerId);
      var right = 0, perLf = {};
      items.forEach(function (it, i) {
        var fs = $("fieldset[data-i='" + i + "']"), ch = $("input:checked", fs), c = ch ? +ch.value : -1;
        perLf[it.lf.id] = perLf[it.lf.id] || { r: 0, n: 0 }; perLf[it.lf.id].n++;
        if (c === it.q.a) { right++; perLf[it.lf.id].r++; }
        $$("input", fs).forEach(function (x) { x.disabled = true; });
        $$(".opt", fs).forEach(function (l) { var o = +l.dataset.o; if (o === it.q.a) l.classList.add("right"); else if (o === c) l.classList.add("wrong"); });
        if (c !== it.q.a) { var ex = document.createElement("div"); ex.className = "expl"; ex.innerHTML = "<b class='no'>" + (c === -1 ? "Nicht beantwortet." : "Falsch.") + "</b> " + esc(it.q.e) + " <a href='#lf" + it.lf.id + "'>Zu LF " + it.lf.id + "</a>"; fs.appendChild(ex); }
      });
      var pts = Math.round(right / items.length * 100), n = note(pts);
      state.trainings.push({ at: Date.now(), jahre: jahre, n: items.length, p: pts }); if (state.trainings.length > 30) state.trainings.shift(); save();
      var mins = Math.round((Date.now() - start) / 60000);
      var res = document.createElement("div");
      res.className = "result";
      res.innerHTML = "<div class='note'>" + n.n + "</div><div><div class='eyebrow' style='color:inherit;opacity:.7'>Ergebnis Prüfungstraining</div><b style='font-size:20px'>" + right + " von " + items.length + " richtig · " + pts + " Punkte · " + n.t + "</b><p>Bearbeitungszeit: " + mins + " Min. Unten siehst du zu jeder falschen Antwort die Erklärung.</p></div>";
      var tbl = "<div class='paper' style='max-width:820px'><h2 style='font-size:20px'>Nach Lernfeld</h2><div class='tbl'><table class='tbl-plain' style='margin-top:10px'><thead><tr><th>Lernfeld</th><th>Richtig</th><th>Quote</th></tr></thead><tbody>" +
        Object.keys(perLf).sort(function (a, b) { return a - b; }).map(function (id) { var r = perLf[id], q = Math.round(r.r / r.n * 100); return "<tr><td><a href='#lf" + id + "'>LF " + id + "</a> " + esc(lfById(+id).titel) + "</td><td class='mono'>" + r.r + "/" + r.n + "</td><td><span class='pill g" + note(q).n + "'>" + q + " %</span></td></tr>"; }).join("") +
        "</tbody></table></div></div>";
      var holder = document.createElement("div"); holder.innerHTML = tbl;
      app.insertBefore(holder.firstChild, $("#tr"));
      app.insertBefore(res, app.children[1]);
      $(".sticky-total").remove();
      $("#timer").remove();
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
  }

  /* ---------- Prüfungsinfo ---------- */
  function renderInfo() {
    var html = "<div class='eyebrow'>Ärztekammer Schleswig-Holstein</div><h1>Die Prüfung in Schleswig-Holstein</h1><p class='lead'>Zuständige Stelle für die MFA-Ausbildung ist die Ärztekammer Schleswig-Holstein. Die Prüfungen finden an ihrer Akademie in Bad Segeberg statt.</p>" +
      "<div class='info-grid'>" +
      "<section class='paper'><h2>Schriftliche Abschlussprüfung</h2><p>Multiple Choice in drei Prüfungsbereichen:</p><ul><li>Behandlungsassistenz</li><li>Betriebsorganisation und -verwaltung</li><li>Wirtschafts- und Sozialkunde</li></ul><p>Dauer: zweimal 120 Minuten und einmal 60 Minuten.</p><p><b>Nächster Termin: 24. November 2026.</b></p></section>" +
      "<section class='paper'><h2>Praktische Prüfung</h2><p>Findet statt, wenn die schriftlichen Ergebnisse vorliegen. Etwa 120 Minuten inklusive Vorbereitung, Prüfungssituation und abschließendem Fachgespräch, an der Akademie der Ärztekammer in Bad Segeberg.</p><p>Übe Abläufe laut: Patient informieren, Hygiene, Durchführung, Dokumentation, Begründung.</p></section>" +
      "<section class='paper'><h2>Zulassung</h2><p>Voraussetzung ist ein lückenlos geführter, von dir und deiner Ausbilderin bzw. deinem Ausbilder unterschriebener Ausbildungsnachweis. Die Berichte müssen in eigenen Worten geschrieben sein.</p><p>Anmeldefristen: <b>15. Februar</b> für den Sommer- und <b>31. August</b> für den Wintertermin.</p></section>" +
      "<section class='paper'><h2>Notenschlüssel</h2><div class='tbl'><table class='tbl-plain'><thead><tr><th>Punkte</th><th>Note</th></tr></thead><tbody>" +
      [["100–92", "1 sehr gut"], ["91–81", "2 gut"], ["80–67", "3 befriedigend"], ["66–50", "4 ausreichend"], ["49–30", "5 mangelhaft"], ["29–0", "6 ungenügend"]].map(function (r) { return "<tr><td class='mono'>" + r[0] + "</td><td>" + r[1] + "</td></tr>"; }).join("") +
      "</tbody></table></div><p style='font-size:14px;color:var(--muted)'>Üblicher 100-Punkte-Schlüssel der Kammern. Diesen Schlüssel nutzt die App. Maßgeblich ist der Schlüssel der Ärztekammer SH.</p></section>" +
      "<section class='paper'><h2>Lehrbuch dazu</h2><p>Die App folgt derselben Lernfeld-Struktur wie gängige Lehrwerke, etwa die Reihe „… in der Arztpraxis“ (Uta Groger, Cornelsen) mit den Bänden Behandlungsassistenz und Leistungsabrechnung. Notiere im Tab „Notizen“ jedes Lernfelds die passenden Buchseiten.</p></section>" +
      "<section class='paper'><h2>Quellen</h2><ul><li><a href='https://www.aeksh.de/medizinische-fachangestellte/ausbildung-fuer-mfa' target='_blank' rel='noopener'>Ärztekammer SH: Ausbildung für MFA</a></li><li><a href='https://www.aeksh.de/medizinische-fachangestellte/ausbildung-fuer-mfa/alles-rund-um-die-pruefung' target='_blank' rel='noopener'>Ärztekammer SH: Alles rund um die Prüfung</a></li><li><a href='https://www.kmk.org' target='_blank' rel='noopener'>KMK: Rahmenlehrpläne</a></li><li><a href='https://www.rki.de/stiko' target='_blank' rel='noopener'>RKI: STIKO-Impfempfehlungen</a></li></ul></section>" +
      "<section class='paper'><h2>Fortschritt mitnehmen</h2><p>Dein Fortschritt liegt nur in diesem Browser. Zum Umzug auf ein anderes Gerät: hier den Code kopieren und auf dem anderen Gerät einfügen.</p><div class='row' style='margin-top:10px'><button class='btn small' id='exp'>Code anzeigen</button><button class='btn small' id='imp'>Code einfügen</button></div>" +
      "<div id='xfer' hidden><label for='xfer-ta' class='eyebrow' style='display:block;margin:12px 0 6px'>Fortschritts-Code</label><textarea id='xfer-ta' style='min-height:110px;font-family:var(--f-mono);font-size:12px'></textarea><div class='row' style='margin-top:8px'><button class='btn small' id='copy'>Kopieren</button><button class='btn small primary' id='load'>Übernehmen</button></div></div></section>" +
      "</div>" + footer();
    app.innerHTML = html;
    var ta = $("#xfer-ta");
    $("#exp").onclick = function () { $("#xfer").hidden = false; ta.value = btoa(unescape(encodeURIComponent(JSON.stringify(state)))); ta.select(); };
    $("#imp").onclick = function () { $("#xfer").hidden = false; ta.value = ""; ta.focus(); };
    $("#copy").onclick = function () {
      var p = navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(ta.value) : Promise.reject();
      p.then(function () { toast("Code kopiert"); }, function () { ta.select(); toast("Markiert – jetzt kopieren"); });
    };
    $("#load").onclick = function () {
      try {
        var p = JSON.parse(decodeURIComponent(escape(atob(ta.value.trim()))));
        for (var k in state) if (p[k]) state[k] = p[k];
        save(); toast("Fortschritt übernommen");
      } catch (e) { toast("Der Code ist unvollständig. Kopiere ihn noch einmal komplett."); }
    };
  }

  /* ---------- Offline-Unterstützung auf dem eigenen Server ---------- */
  try {
    if ("serviceWorker" in navigator && location.protocol === "https:" && !/claude\.ai|claudeusercontent/.test(location.hostname) && window.MFA_SW) {
      navigator.serviceWorker.register("sw.js").catch(function () {});
    }
  } catch (e) {}

  route();
})();
