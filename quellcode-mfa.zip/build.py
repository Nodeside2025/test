#!/usr/bin/env python3
"""Baut die App: deploy/site/ (für den VPS) und preview.html (Artifact-Vorschau)."""
import pathlib, time, base64
from PIL import Image

root = pathlib.Path(__file__).parent
src = root / "src"
site = root / "deploy" / "site"
site.mkdir(parents=True, exist_ok=True)

shell = (src / "shell.html").read_text(encoding="utf-8")
data = "\n".join((src / f"data{i}.js").read_text(encoding="utf-8") for i in (1, 2, 3))
app = (src / "app.js").read_text(encoding="utf-8")
version = time.strftime("%Y%m%d%H%M")

def b64(name):
    return "data:image/png;base64," + base64.b64encode((src / name).read_bytes()).decode()
shell = shell.replace("__LOGO_N__", b64("logo-n.png"))

# App-Icons: Nodeside-N auf dunklem Grund
n = Image.open(src / "logo-n.png").convert("RGBA")
for size in (192, 512):
    ic = Image.new("RGBA", (size, size), (11, 18, 26, 255))
    h = int(size * 0.5); w = int(n.width * h / n.height)
    ic.alpha_composite(n.resize((w, h), Image.LANCZOS), ((size - w) // 2, (size - h) // 2))
    ic.convert("RGB").save(site / f"icon-{size}.png")

scripts = f"<script>window.MFA_LOGO_FULL={b64('logo-full.png')!r};</script>\n<script>\n{data}\n</script>\n<script>\n{app}\n</script>\n"

vps_head = (
    "<!doctype html>\n<html lang=\"de\">\n<head>\n<meta charset=\"utf-8\">\n"
    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n"
    "<link rel=\"manifest\" href=\"manifest.webmanifest\">\n<link rel=\"icon\" href=\"icon-192.png\" type=\"image/png\">\n"
    "<link rel=\"apple-touch-icon\" href=\"icon-192.png\">\n<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n"
    "<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}</style>\n"
)
vps = vps_head + shell + "\n<script>window.MFA_SW=true;</script>\n" + scripts + "</html>\n"
(site / "index.html").write_text(vps, encoding="utf-8")
(site / "sw.js").write_text((src / "sw.js").read_text(encoding="utf-8").replace("__VERSION__", version), encoding="utf-8")
for f in ("manifest.webmanifest",):
    (site / f).write_text((src / f).read_text(encoding="utf-8"), encoding="utf-8")

(root / "preview.html").write_text(shell + "\n" + scripts, encoding="utf-8")
print("gebaut:", site / "index.html", f"({len(vps)//1024} KB)")
